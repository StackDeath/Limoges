let textHTML="";

function traiterVac(){

    $.get("https://data.education.gouv.fr/api/records/1.0/search/?dataset=fr-en-calendrier-scolaire&q=location='Limoges' and start_date>'2021-09-01'",voirBase);
}



function voirBase(data){

    console.log(data);

    for(i=0;i<data.records.length;i++){

    
    console.log(data.records[i].fields.location);

    }

    

    textHTML += "<table class='table'>";

    textHTML += "<thead>";
    textHTML += "<tr>";

    textHTML += "<th scope='col'>Ville</th>";
    textHTML += "<th scope='col'>Zone</th>";
    textHTML += "<th scope='col'>Date Début</th>";
    textHTML += "<th scope='col'>Date de fin</th>";
    textHTML += "<th scope='col'>Type vacance</th>";
    textHTML += "<th scope='col'>Année scolaire</th>"; 
    

    textHTML += "</tr>";
    textHTML += "</thead>";

    textHTML += "<tbody>";
    for(i=0;i<data.records.length;i++){
    textHTML += "<tr>";

    textHTML += "<td>"+data.records[i].fields.location+"</td>";
    textHTML += "<td>"+data.records[i].fields.zones+"</td>";
    textHTML += "<td>"+data.records[i].fields.start_date+"</td>";
    textHTML += "<td>"+data.records[i].fields.end_date+"</td>";
    textHTML += "<td>"+data.records[i].fields.description+"</td>";
    textHTML += "<td>"+data.records[i].fields.annee_scolaire+"</td>";
    

    textHTML += "</tr>";
    }
    textHTML += "</tbody>";

    textHTML += "</table>";

    $("#base").html(textHTML);

}