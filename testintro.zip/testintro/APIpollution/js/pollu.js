let textHTML="";

//Utilisation pour la prévision d'aujourd'hui
// https://api.openweathermap.org/data/2.5/air_pollution?lat=45.833619&lon=1.261105&appid=baff69ed35416d515661b0d141f6c6eb

//Utilisation de forcast pour prédire le taux de pollution
// https://api.openweathermap.org/data/2.5/air_pollution/forecast?lat=45.833619&lon=1.261105&appid=baff69ed35416d515661b0d141f6c6eb

//Utilisation pour les Données historiques sur la pollution atmosphérique de Limoges.
//  https://api.openweathermap.org/data/2.5/air_pollution/history?lat=45.833619&lon=1.261105&start=1606223802&end=1606482999&appid=baff69ed35416d515661b0d141f6c6eb

// doc : https://openweathermap.org/api/air-pollution

function traiterpol(){

    let url = 'https://api.openweathermap.org/data/2.5/air_pollution?lat=45.833619&lon=1.261105&appid=baff69ed35416d515661b0d141f6c6eb';

    $.get(url,voirPol);
}


function voirPol(data){
    console.log(data);


    
    //donner une couleur au texte
    //<th style="background-color: yellow">Data 2</th>



    textHTML += "<table class='table'>";

    textHTML += "<thead>";
    textHTML += "<tr>";

    textHTML += "<th align=center scope='col'>Dioxyde d'azote no2</th>"
    textHTML += "<th align=center scope='col'>Ozone pm10</th>";
    textHTML += "<th align=center scope='col'>Particules en suspension 03</th>";
    textHTML += "<th align=center scope='col'>Particules en suspension pm 2_5</th>";


    textHTML += "</tr>";
    textHTML += "</thead>";

    textHTML += "<tbody>";

    textHTML += "<tr>";

   

    textHTML += "<td align=center>"+data.list[0].components.no2+"</td>";
    textHTML += "<td align=center>"+data.list[0].components.pm10+"</td>";
    textHTML += "<td align=center>"+data.list[0].components.o3+"</td>";
    textHTML += "<td align=center>"+data.list[0].components.pm2_5+"</td>";




    textHTML += "</tr>";
    
    textHTML += "</tbody>";

    textHTML += "</table>";

    $("#polPol").html(textHTML);
}