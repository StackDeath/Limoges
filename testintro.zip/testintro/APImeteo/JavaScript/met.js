let textHTML="";

//const APIKEY = 'baff69ed35416d515661b0d141f6c6eb';

function traitermet(){

let url = 'https://api.openweathermap.org/data/2.5/weather?lat=45.833619&lon=1.261105&lang=fr&appid=baff69ed35416d515661b0d141f6c6eb&units=metric' ;


$.get(url,voirMet);


}


// https://api.openweathermap.org/data/2.5/weather?lat=45.833619&lon=1.261105&lang=fr&appid=baff69ed35416d515661b0d141f6c6eb&units=metric;



function voirMet(data){
    console.log(data);

   // let unix_timestamp = data.dt
   // // Create a new JavaScript Date object based on the timestamp
   // // multiplied by 1000 so that the argument is in milliseconds, not seconds.
   // var date = new Date(unix_timestamp * 1000);
   // // Hours part from the timestamp
   // var hours = date.getHours();
   // // Minutes part from the timestamp
   // var minutes = "0" + date.getMinutes();
   // 
   // // Will display time in 10:30:23 format
   // var formattedTime = hours + 'h' + minutes.substr(-2) + 'm';

   

   let unix_timestamp = data.dt
    var a = new Date(unix_timestamp * 1000);
    var months = ['Janvier','Fevrier','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Decembre'];
    var year = a.getFullYear();
    var month = months[a.getMonth()];
    var date = a.getDate();
    var hour = a.getHours();
    var min = a.getMinutes();
    var sec = a.getSeconds();
    var time = date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec;
   // let sunrise = window.moment(data.sys.sunrise).format('HH:mm a');
    
    
    
  
    

    textHTML += "<table class='table'>";

    textHTML += "<thead>";
    textHTML += "<tr>";
    textHTML += "<h1 align=center> Nous sommes le  "+date+" " +month+" " +year+"</h3>";

    textHTML += "<th align=center scope='col'>Ic</th>";
    textHTML += "<th align=center scope='col'>Temps</th>";
    textHTML += "<th align=center scope='col'>Pression</th>";
    textHTML += "<th align=center scope='col'>Humidité</th>";
    textHTML += "<th align=center scope='col'>Vent</th>";
    textHTML += "<th align=center scope='col'>Temps Max</th>"; 
    textHTML += "<th align=center scope='col'>Temps Min</th>"; 
    //textHTML += "<th align=center scope='col'>Sunrise</th>"; 


    textHTML += "</tr>";
    textHTML += "</thead>";

    textHTML += "<tbody>";

    textHTML += "<tr>";

    textHTML += "<td align=center>"+data.weather[0].icon+"</td>";
    textHTML += "<td align=center>"+data.weather[0].description+"</td>";
    textHTML += "<td align=center>"+data.main.pressure+"</td>";
    textHTML += "<td align=center>"+data.main.humidity+"</td>";
    textHTML += "<td align=center>"+data.wind.speed+"</td>";
    textHTML += "<td align=center>"+data.main.temp_max+"</td>";
    textHTML += "<td align=center>"+data.main.temp_min+"</td>";
   // textHTML += "<td align=center>"+data.sys.sunrise+"</td>";
  

    textHTML += "</tr>";
    textHTML += "</tbody>";

    $("#baseMet").html(textHTML);
}


//---------------------------------------------------deuxieme partie-------------------------------------------

//http://openweathermap.org/img/wn/10d@2x.png

//---------------------------Troisieme partie --------------------------------------
function traiterTest(){
textHTML += "<section class=banner id=banner>";
textHTML += "<div class=content>";
textHTML += "<h2>test page</h2>";
textHTML += "<h3>Ceci est un test</h3> <br>";
textHTML += "<p> Je suis le test qui va determiner si ça marche</p>";
textHTML += "</div>";

$("#baseMet").html(textHTML);
}


/*


<section class="banner" id="banner">
<div class="content">
    <h2>Test page</h2>
    <h3> Ceci est un texte</h3> <br>
    <p>Pour acceder cliquez sur le bouton juste en dessous :</p>
        <a href="Connexion.html" class="btn">test</a>
</div>
*/