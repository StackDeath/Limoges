// petit mémo 
// const -> récupere la valeur choisi dans HTML 
const timeEL = document.getElementById('time');
const dateEL = document.getElementById('date');
const currentWeatherItemsEL = document.getElementById('current-weather-items');
const timezone = document.getElementById('time-zone');
const countryEL = document.getElementById('country');
const weatherForecastEL = document.getElementById('weather-forecast');
const currentTempEL = document.getElementById('current-temp');



const jours = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];
const months = ['Janvier', 'Fevrier', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Decembre'];

const APIKEY = 'baff69ed35416d515661b0d141f6c6eb';

setInterval(() => {
    //let unix_timestamp = data.dt
    const time = new Date();
    // const year = a.getFullYear();
    const month = time.getMonth();
    const date = time.getDate();
    const day = time.getDay();
    const hour = time.getHours();
    const hoursIn12HrFormat = hour >= 13 ? hour % 12 : hour
    const minutes = time.getMinutes();
    //const sec = a.getSeconds();
    // const time = date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec;
    const ampm = hour >= 12 ? 'pm' : 'AM'

    // Mise à jour de l'heure
    timeEL.innerHTML = hoursIn12HrFormat + ':' + minutes + ' ' + `<span id="am-pm">${ampm}</span>`

    dateEL.innerHTML = jours[day] + ' ' + date + ' ' + months[month];

   
}, 1000);

getWeatherData();
function getWeatherData() {

    navigator.geolocation.getCurrentPosition((succes) => {
        console.log(succes);

         let {latitude, longitude} = succes.coords;

        fetch(`https://api.openweathermap.org/data/2.5/onecall?lat=${latitude}&lon=${longitude}&exclude=hourly,minutely&lang=fr&appid=${APIKEY}&units=metric`).
            then(res => res.json()).then(data => {
                console.log(data);
                showWeatherData(data);
            })
    })


}

function showWeatherData(data) {
    let { humidity, pressure, sunrise, sunset, temp, wind_speed } = data.current;
    timezone.innerHTML = data.timezone;
    

    currentWeatherItemsEL.innerHTML =           `<div class="weather-item">
                                                      <div>Température : </div>
                                                     <div>${temp} C°</div>
                                                 </div>
    
                                                <div class="weather-item">
                                                      <div>Humidité :</div>
                                                      <div>${humidity}%</div>
                                                </div>

                                                <div class="weather-item">
                                                     <div>Vent :</div>
                                                     <div>${wind_speed} km/h</div>
                                                 </div>

                                                <div class="weather-item">
                                                    <div>Pression :</div>
                                                    <div>${pressure} Pa</div>
                                                 </div>
                                  
                                                 <div class="weather-item">
                                                     <div>Jour :</div>
                                                     <div>${moment(sunrise * 1000).format('HH:mm a')}</div>
                                                 </div>

                                                <div class="weather-item">
                                                     <div>Nuit :</div>
                                                     <div>${moment(sunset * 1000).format('HH:mm a')}</div>
                                                 </div>
                                               `;

                let otherDayForcast = ''
                data.daily.forEach((day, idx)=> {
                    if(idx == 0){
                        currentTempEL.innerHTML = `
                                                    <img src="https://openweathermap.org/img/wn/${day.weather[0].icon}@2x.png" alt="weather icon" class="w-icon"> 
                                                        <div class="other">
                                                        <div class="day">${moment().format('dddd, D')}</div>
                                                         <div class="temp">Temps max : ${day.temp.max}&#176; C</div>
                                                         <div class="temp">Temps min : ${day.temp.min}&#176; C</div>
                                                     </div>
                                                  `
                    }else{
                        otherDayForcast += `           
                         <div class="weather-forecast-item">
                             <div class="day">${moment(day.dt * 1000).format('dddd, D')}</div>
                             <img src="https://openweathermap.org/img/wn/${day.weather[0].icon}@2x.png" alt="weather icon" class="w-icon">                   
                             <div class="temp">Temps max :  ${day.temp.max}&#176; C</div>
                             <div class="temp">Temps min : ${day.temp.min}&#176; C</div>
                        </div>
                        
                        `
                    }
    })


    weatherForecastEL.innerHTML = otherDayForcast;

}