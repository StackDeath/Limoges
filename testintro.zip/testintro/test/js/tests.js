let textHTML="";

function traitertel(){

    let url = 'http://api.openweathermap.org/data/2.5/air_pollution?lat=45.833619&lon=1.261105&appid=baff69ed35416d515661b0d141f6c6eb';
    console.log(url);
    $.get(url,traiterPols);
}




function traiterPols(data){
    console.log(data);

    textHTML += "<table class='table'>";

    textHTML += "<thead>";
    textHTML += "<tr>";

    textHTML += "<th scope='col'>Temps</th>";
    textHTML += "<th scope='col'>Temps</th>";
    textHTML += "<th scope='col'>Temps</th>";
    textHTML += "<th scope='col'>Description</th>";
    textHTML += "<th scope='col'>Pression</th>";
    textHTML += "<th scope='col'>Humidité</th>";
    textHTML += "<th scope='col'>Vent</th>";
    textHTML += "<th scope='col'>Jour</th>"; 
    textHTML += "<th scope='col'>Nuit</th>"; 

    textHTML += "</tr>";
    textHTML += "</thead>";

    textHTML += "<tbody>";

    textHTML += "<tr>";

    textHTML += "<td>"+data.list[0].main+"</td>";
    textHTML += "<td>"+data.list[0].components.co+"</td>";
    textHTML += "<td>"+data.list[0].components.no+"</td>";
    textHTML += "<td>"+data.list[0].components.no2+"</td>";
    textHTML += "<td>"+data.list[0].components.o3+"</td>";
    textHTML += "<td>"+data.list[0].components.so2+"</td>";
    textHTML += "<td>"+data.list[0].components.pm2_5+"</td>";
    textHTML += "<td>"+data.list[0].components.pm10+"</td>";
    textHTML += "<td>"+data.list[0].components.nh3+"</td>";


    textHTML += "</tr>";
    
    textHTML += "</tbody>";

    textHTML += "</table>";

    $("#basePols").html(textHTML);
}