using Microsoft.VisualStudio.TestTools.UnitTesting;
using Fraction;
using System;

namespace TestUniFraction
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod] // attribut --> nom reserv� --> pas variable 
        public void TestConstructeur2param()
        {
            Random Alea = new Random();

            int n, d;

            for(int i=0; i<10000000; i++)
            {
                n = Alea.Next();
                d = Alea.Next(1, 1000000); // verifi deno n'est pas nul
                Frac f = new Frac(n, d);
                Assert.AreEqual(n, f.Numerateur); // compare, test si c est vrai ou faux
                Assert.AreEqual(d, f.Denominateur);
            }
            

        }

        [TestMethod]
        [ExpectedException(typeof(DivideByZeroException))] // la methode doit lever une exeption 

        public void TestConstructeur2ParamExecp()
        {
            Frac f = new Frac(10, 0);
        }

        [TestMethod]
        public void TestConstructeur2paramV2()
        {
            Frac f = new Frac(10, 3);
            bool constructionOK;

            constructionOK = (10 == f.Numerateur) && (3 == f.Denominateur); // 2e tec

            Assert.IsTrue(constructionOK); //2eme tec
        }
    } 
}
