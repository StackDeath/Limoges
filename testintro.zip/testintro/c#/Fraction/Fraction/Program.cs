﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fraction
{
    class Program
    {
        static void Main(string[] args)
        {
            #region premier
            /*
             Frac f2 = new Frac(3, 2);

             Console.WriteLine("Resultat Fraction :" + f2.Div());
             Console.WriteLine("Resultat Multi :" + f2.Multiplica());
            Console.WriteLine("Resultat Div Fraction :" + f2.DivFrac(5));
             Console.WriteLine("Resultat Add :" + f2.AddFrac());
            */
            #endregion


            Frac f1 = new Frac(10, 3);
            Frac f2 = new Frac(1, 4);

            //tester F1 * F2
            Frac fRes;
            fRes = f1.Add(f2);

            fRes.AfficherDBG();

            fRes = f2.Add(f1);

            fRes.AfficherDBG();

            //Tester multiplication des div
            fRes = f1.Multi(2);
            fRes.AfficherDBG();

            fRes = f1.Div(2);
            fRes.AfficherDBG();

            //derniers test levée d'exception
            // fRes = new Frac(10, 0);

            fRes = fRes.Div(0);

            //  Console.WriteLine("Valeur :" + f1.Valeur);
        }
    }
}
