﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fraction
{
   public class Frac // ajout public pour utilisation exterieur
    {
        /*
        #region Avant correction
        private int _Num = 1;
        private int _Den = 2;

        #region Frac num, dem
        public Frac()
        {
            _Num = 1;
            _Den = 2;
        }

        public Frac(int num, int deno)
        {
            num = _Num;
            deno = _Den;
            float resultat;

            if (num == 0 && deno == 0)
            {
                Console.WriteLine("Y'a pas zéro mon grand");
            }
        }
        #endregion

        #region Get 
        public int Num { get => _Num; set => _Num = value; }
        public int Den { get => _Den; set => _Den = value; }
        #endregion

        #region Val Deci
        public float Div()
        {
            float resultat;

            resultat = _Num / _Den;

            return resultat;
        }
        #endregion

        #region Multi
        public float Multiplica()
        {
            float resultat;

            resultat = _Num * _Den;

            return resultat;
        }
        #endregion

        #region Div Frac
        public float DivFrac(int entiers)
        {
            float resultat;

            resultat = (_Num / _Den) * entiers;

            return resultat;
        }
        #endregion

        #region Add Frac
        public float AddFrac()
        {
            float resultat;

            resultat = (_Num / _Den) + (_Num / _Den  );

            return resultat;
        }
        #endregion
        #endregion
        */


        #region Correction fraction

        protected int numerateur;
        protected int denominateur;


        #region Methode de GET
        public int Numerateur { get => numerateur; set => numerateur = value; }
        public int Denominateur
        {
            get => denominateur;
            set
            {
                if (value == 0) throw (new DivideByZeroException());
                denominateur = value;
            }
        }
        #endregion

        #region 2 constructeurs

        public Frac()
        {
            numerateur = 1;
            denominateur = 1;
        }

        public Frac(int n, int d)
        {
            if (d == 0) throw (new DivideByZeroException());
            numerateur = n;
            denominateur = d;
        }
        #endregion

        #region retourne val dec

        public double GetValeur()
        {
            return 1.0 * numerateur / denominateur;
        }

        public double Valeur { get => 1.0 * numerateur / denominateur; } //deuxieme version
        #endregion

        #region multi par un entiers

        public Frac Multi(int a)
        {
            return new Frac(a * this.numerateur, denominateur);
        }

        #endregion

        #region division

        public Frac Div(int a)
        {
            if (a == 0) throw (new DivideByZeroException());
            return new Frac(numerateur, a * denominateur);
        }

        #endregion

        #region add

        public Frac Add(Frac f)
        {
            int n = this.numerateur * f.denominateur + f.numerateur * this.denominateur;
            int d = this.denominateur * f.denominateur;

            return new Frac(n, d);
        }

        #endregion


        public void AfficherDBG()
        {
            Console.WriteLine("Fraction : " + numerateur + "/" + denominateur);
        }
        #endregion
    }
}
