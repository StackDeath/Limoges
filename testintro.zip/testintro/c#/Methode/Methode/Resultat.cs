﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Methode
{
    class Resultat
    {
        private double note;
        private double coef;
        private Etudiant etu;
        private Matiere mat;

        public double getNote()
        {
            return note;
        }

        public double getCoef()
        {
            return coef;
        }
        public Etudiant getEtu()
        {
            return etu;
        }
        public Matiere getMat()
        {
            return mat;
        }

        public Resultat(double n, double c, Etudiant e, Matiere m)
        {
            note = n;
            coef = c;
            etu = e;
            mat = m;
        }
        
    }
}
