﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Methode
{
    class Matiere
    {
        private String nom;
        private List<Resultat> listeResultats = new List<Resultat>();

        public String getNom()
        {
            return nom;
        }

        public void ajouterResultat(Resultat r)
        {
            listeResultats.Add(r);
        }

        public Matiere(String n)
        {
            nom = n;
        }
    }
}
