﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Methode
{
    class Etudiant
    {
        private String nom;
        private List<Resultat> listeResultats = new List<Resultat>();
        public String getNom()
        {
            return nom;
        }

        public void ajouterResultat(Resultat r)
        {
            listeResultats.Add(r);
        }

        public void ajouterNote(double no, double co, Matiere ma)
        {
            //Exemple d'utilisation 
            //Etudiant etu01 = new Etudiant("phyl78");
            // etu01 ajouterNote(10, 8, mat1, "Japonnais");
            // => etu01 est this : this est l'objet sur lequel on a appelé la méthode 
            Resultat r = new Resultat(no, co, this ,ma);
            listeResultats.Add(r);

        }

        //retourner le meilleur resultat
        public List<Resultat> getMeilleurResultat()
        {
            List<Resultat> listeRes = new List<Resultat>();
            double noteMax = -1;

            //recherche de la note max
            foreach(Resultat r in listeResultats)
            {
                if (r.getNote()> noteMax)
                {
                    noteMax = r.getNote();
                    
                }
            }

            //Creation de la liste des resultats max
            foreach (Resultat r in listeResultats)
            {
                if (r.getNote() == noteMax)
                {
                    listeRes.Add(r);

                }
            }

            return listeRes;
        }

        //retourne la moyennes des resultats
        public double getMoyenne()
        {
            double moyenne;
            double sommeNotes = 0, sommeCoef = 0;

            foreach (Resultat r in listeResultats)
            {
                sommeNotes += r.getNote(); // sommeNote = sommeNotes + r.getNote();
                sommeCoef += r.getCoef();
            }
            moyenne = sommeNotes / sommeCoef;

            return moyenne;
        }

        public Matiere getMeilleurMatiere()
        {
            Matiere matMax = null;
            double noteMax = -1;

            foreach (Resultat r in listeResultats)
            {
                if (r.getNote() > noteMax)
                {
                    noteMax = r.getNote();
                    matMax = r.getMat();
                }
            }
            return matMax;
        }

        public Etudiant(String n)
        {
            nom = n;
        }
    }
}
