﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using TestUnitaire;

namespace BankTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            BankAccount ba = new BankAccount("Titi", 100);

            ba.Credit(50);

            Assert.AreEqual(150, ba.Balance, 0.001, "Erreur de crédit ");
        }


        [TestMethod]
        public void TestDebit()
        {
            BankAccount ba = new BankAccount("Titi", 100);

            ba.Credit(50);

            Assert.AreEqual(50, ba.Balance, 0.001, "Erreur de debit ");
        }
    }
}
