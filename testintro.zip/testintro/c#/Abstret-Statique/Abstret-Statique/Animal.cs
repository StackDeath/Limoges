﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abstret_Statique
{
    class Animal
    {
        static public int numeroteur = 0; //Static : variable de classe et non d'objet
                                          //Numéroteur est commun à tous les objets de la classe

        static public int DOMESTIQUE = 0;
        static public int SAUVAGE = 1;
        static public int ETEINT = 2;

        public int type;

        public int numero;
        public String nom;

        public Animal()
        {
            numeroteur++;
            nom = "Inconnu au bataillon";
            numero = numeroteur;
            type = DOMESTIQUE;
        }
    }
}
