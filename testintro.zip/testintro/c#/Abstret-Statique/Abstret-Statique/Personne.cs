﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abstret_Statique
{
    abstract class Personne
    {
        private String nom;

        public Personne(String n)
        {
            nom = n;
        }

        public String getNom()
        {
            return nom;
        }

        abstract public void Afficher();
  
    }
}
