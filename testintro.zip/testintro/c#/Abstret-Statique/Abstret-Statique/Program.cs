﻿using System;

namespace Abstret_Statique
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("----------------------------------------------------");

            Animal A1 = new Animal();
            Console.WriteLine("numero de A1 :" + A1.numero);

            Console.WriteLine("----------------------------------------------------");

            Animal A2 = new Animal();
            Console.WriteLine("numero de A2 :" + A2.numero);
            Console.WriteLine("----------------------------------------------------");

            //Verifier type animal
            //Acceder à une méthode ou une variable statique on passe par la classe 
            if(A1.type == Animal.DOMESTIQUE)
            {
                //rien
            }
            Console.WriteLine("----------------------------------------------------");

            //Plus grande valeur représentable avec un entier
            Console.WriteLine("Max des entiers :" + int.MaxValue);

            Console.WriteLine("----------------------------------------------------");
            //passage au negatif
            int a = int.MaxValue;

            a++;

            Console.WriteLine(a);
        }
    }
}
