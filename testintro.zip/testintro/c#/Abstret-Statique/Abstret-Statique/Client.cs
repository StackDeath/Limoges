﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abstret_Statique
{
    class Client : Personne
    {
        private double CA;

        public Client() : base("Nothing")
        {

        }

        override public void Afficher()
        {
            Console.WriteLine("Client :" +this.getNom()+ CA);
        }
    }
}
