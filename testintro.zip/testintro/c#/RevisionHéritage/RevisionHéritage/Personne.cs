﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RevisionHéritage
{
    class Personne : Ressource
    {
        public List<Ressource> listeRessources = new List<Ressource>();

        private String nom;

        public Personne(String ident, String n) : base(ident)
        {
            nom = n;
        }

        public void ajouterRessource(Ressource R)
        {
            listeRessources.Add(R);
        }

        public override void AfficherDBG()
        {
            //Première forme de départ
            //Console.Write("Personne :" + nom + " ->");
            // base.AfficherDBG();

            Console.Write("Persone " + identifiant + " : " + nom);
        }

        public void AfficherRessources()
        {
            // --Ressource utilisées :
            //   - ident001;
            //   - ident002;

            //possible manip interne
           // Ressource R1 = new Ressource("97613");


            foreach(Ressource r in listeRessources)
            {
                Console.WriteLine("- " + r.Identifiant);
                // ou bien :
                // Console.WriteLine("- "+ r.getidentifiant);
            }
        }
    }
}
