﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RevisionHéritage
{
    class Ressource
    {

        protected String  identifiant;

        //Accès en lecture seule à l'identifiant
        public String Identifiant { get => identifiant; }
        public String getidentifiant() { return identifiant; }

        //Constructeur avec 1 parametre 
        public Ressource(String id)
        {
            identifiant = id;
        }

        public virtual void AfficherDBG()
        {
            Console.WriteLine(identifiant);
        }
    }
}
