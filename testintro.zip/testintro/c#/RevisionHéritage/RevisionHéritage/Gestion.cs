﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RevisionHéritage
{
    class Gestion
    {
        public List<Ressource> listeRessources = new List<Ressource>();

        public void ajouterRessource(Ressource r)
        {
            listeRessources.Add(r);
        }

        public void AfficherDBG()
        {
            Console.WriteLine("__ Ressources __ ");
            foreach(Ressource r in listeRessources)
            {
                r.AfficherDBG();
            }
        }

    }
}
