﻿using System;

namespace RevisionHéritage
{
    class Program
    {
        static void Main(string[] args)
        {
            //Test de ressource 
            Ressource r1 = new Ressource("A089JK");

            r1.AfficherDBG();


            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");


            //Test de materiel
            Materiel m1 = new Materiel("79650");

            m1.AfficherDBG();

            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");

            Materiel m2 = new Materiel("79650", 60.7);

            m2.AfficherDBG();

            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");

            //Test de MatInfo

            MatInfo MI1 = new MatInfo("90460LM", 5000, 950);
            MatInfo MI2 = new MatInfo("67301PO", 5000, 750);
            MatInfo MI3 = new MatInfo("34516RH", 5000, 350);

            MI1.AfficherDBG();

            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");

            //test de personne

            Personne p1 = new Personne("5030","Billy");

            p1.AfficherDBG();

            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");

            //test de gestion

            Gestion gest = new Gestion();

            gest.ajouterRessource(r1);

            gest.ajouterRessource(m1);

            gest.ajouterRessource(MI1);

            gest.ajouterRessource(MI2);

            gest.ajouterRessource(MI3);

            gest.ajouterRessource(p1);

            gest.AfficherDBG();

            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
            Console.WriteLine("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");

            // test P1 List
            p1.ajouterRessource(MI1);
            p1.ajouterRessource(MI2);
            p1.ajouterRessource(p1);

            p1.AfficherRessources();



        }
    }
}
