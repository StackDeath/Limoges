﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RevisionHéritage
{
    //Héritage ( : Ressource)
    class Materiel : Ressource
    {
        private double prixAchat;



        public Materiel(String ident) : base("Mat-"+ident)
        {
            // identifiant = id;
            // base --> il faut appeler le constructeur de la classe mère

            prixAchat = 0;
        }

        //constructeur 2 parametre 
        public Materiel(String ident, double pA) : base(ident)
        {
            prixAchat = pA;
            
        }

        public override void AfficherDBG()
        {
            // Materiel : . . . identifant . . .
            Console.Write("Materiel ({0}) :", prixAchat);

            //appel de l'affichage de la classe mere ("super-classe")
            base.AfficherDBG();
        }
    }
}
