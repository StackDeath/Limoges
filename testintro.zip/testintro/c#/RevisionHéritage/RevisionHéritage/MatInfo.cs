﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RevisionHéritage
{
    class MatInfo : Materiel
    {
        private int WattElectrique;

        public MatInfo(String ident, double prix, int puiss) : base(ident, prix)
        {
            WattElectrique = puiss;
        }

        public override void AfficherDBG()
        {
            base.AfficherDBG();
            Console.WriteLine("    =>" + WattElectrique + " W");
        }
    }
}
