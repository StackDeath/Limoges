﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Unitaire;

namespace testUnitaireNote
{
    [TestClass]
    public class UnitTestNoteDevoir
    {
        [TestMethod]
        public void TestMethod1()
        {
            Devoir d1 = new Devoir("DS", 1, 20);
            Devoir d2 = new Devoir("Interro", 0.5, 10);

            Etudiant e1 = new Etudiant("Toto");

            e1.AjouterResultat(new Resultat(d1, 14));
            e1.AjouterResultat(new Resultat(d2, 7));


            Assert.AreEqual(e1.calculerMoyenne(), 14);
        }
    }
}
