﻿using System;

namespace Unitaire
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Devoir d1 = new Devoir("DS", 1, 20);
            Devoir d2 = new Devoir("Interro", 0.5, 10);


            Etudiant e1 = new Etudiant("Billy");

            e1.AjouterResultat(new Resultat(d1, 14));
            e1.AjouterResultat(new Resultat(d2, 7));


            Console.WriteLine("Moyenne :" e1.calculerMoyenne);
        }
    }
}
