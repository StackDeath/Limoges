﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Unitaire
{
    public class Devoir
    {
        protected String _nom;
        protected double _coef;
        protected double _valMax;
        protected List<Resultat> listeResultats = new List<Resultat>();

        public double Coef { get => _coef; set => _coef = value; }
        public double ValMax { get => _valMax; set => _valMax = value; }
        public string Nom { get => _nom; set => _nom = value; }

        public Devoir(String n, double c, int vMax)
        {
            _nom = n;
            _coef = c;
            _valMax = vMax;
        }

        public void AjouterRes(Resultat resultat)
        {
            listeResultats.Add(resultat);
        }
    }
}
