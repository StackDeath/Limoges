﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Unitaire
{
   public class Resultat
    {
        protected double _note;
        protected Devoir _devoir;

        public double Note { get => _note; set => _note = value; }
        public Devoir Dev { get => _devoir; set => _devoir = value; }

        public Resultat(Devoir d, double n)
        {
            if(n > d.ValMax)
            {
                throw new ArgumentOutOfRangeException("note > max");
            }
            _devoir = d;
            _note = n;
        }
    }
}
