﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Unitaire
{
   public class Etudiant
    {
        protected String _nom;
        protected List<Resultat> listeResultats = new List<Resultat>();

        public String Nom { get => _nom; set => _nom = value; }
        
        public Etudiant(String n)
        {
            _nom = n;
        }

        public double calculerMoyenne()
        {
            if (listeResultats.Count == 0) return -1;
            double Moyenne;
            double somme = 0;
            double sommeCoef = 0;

            foreach( Resultat r in listeResultats )
            {
                somme += (20 * r.Note / r.Dev.ValMax) * r.Dev.Coef;
                sommeCoef += r.Dev.Coef;
            }
            Moyenne = somme / sommeCoef;

            return Moyenne;
        }

        public void AjouterResultat(Resultat resultat)
        {
            listeResultats.Add(resultat);
        }
    }
}
