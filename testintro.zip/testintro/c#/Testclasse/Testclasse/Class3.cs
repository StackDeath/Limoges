﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Testclasse
{
    class Poste
    {
        private String nom;

        public string Nom { get => nom; set => nom = value; }
    }
}
