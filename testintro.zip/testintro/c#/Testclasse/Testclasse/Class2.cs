﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Testclasse
{
    class Employe : Personne
    {
        Poste poste;
        public Employe() : base(007, "CM")
        {

        }
        public Poste Poste { get => poste; set => poste = value; }
    }
}
