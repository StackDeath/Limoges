﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Testclasse
{
    class Client : Personne
    {
        List<Facture> listeFacture;

        Poste poste;
        public Client() : base(456, "= Soleil")
        {
            listeFacture = new List<Facture>();
        }

        //ajouter une facture à la liste des facteurs du client 
        public void AjouterFacture(Facture f)
        {
            listeFacture.Add(f);
        }

        public void AfficherDbg()
        {
            Console.WriteLine("Client : " + Id+" "+Nom);
            foreach(Facture fact in listeFacture)
            {
                Console.WriteLine("   - facture " + fact.NumFacture);
            }
        }
    }
}
