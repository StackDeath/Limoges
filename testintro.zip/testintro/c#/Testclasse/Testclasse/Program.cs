﻿using System;

namespace Testclasse
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("!------------------------------------------------------------!");

            #region Premier constructeur
            Personne p1 = new Personne(50, "Paul");
             Personne p2 = new Personne(30, "Jean");

            p1.AfficherDBG();
            p2.AfficherDBG();
            #endregion

            Console.WriteLine("!------------------------------------------------------------!");
            Console.WriteLine("!------------------------------------------------------------!");

            #region Deuxieme constru Compteur
            Personne p3 = new Personne("Giles");
            Personne p4 = new Personne("Lucas");
           

            p3.AfficherDBG();
            p4.AfficherDBG();
            #endregion


            Console.WriteLine("!------------------------------------------------------------!");
            Console.WriteLine("!------------------------------------------------------------!");

            //methode statique : appele a travers la classe
            Console.WriteLine("Nombre Alea :" + Personne.GenereNbrAlea());

            Console.WriteLine("!------------------------------------------------------------!");
            Console.WriteLine("!------------------------------------------------------------!");

            //TestClient facture
            Client c = new Client();

            Facture F1 = new Facture();
            Facture F2 = new Facture();
            Facture F3 = new Facture();

            F1.NumFacture = " Fac2021 ";
            F2.NumFacture = " Fac2222 ";
            F3.NumFacture = " Fac2657 ";

            c.AjouterFacture(F2);
            c.AjouterFacture(F3);

            c.AfficherDbg();

            Console.WriteLine("!------------------------------------------------------------!");
            Console.WriteLine("!------------------------------------------------------------!");


            Console.ReadKey();
        }
    }
}
