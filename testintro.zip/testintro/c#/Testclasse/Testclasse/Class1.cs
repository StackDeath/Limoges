﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Testclasse
{
    class Personne
    {
        public static int  Compteur = 0;



        private int id; //protected -> privée mais récuperable par héritage
        private string nom;

        public int Id { get => id; set => id = value; }
        public string Nom { get => nom; set => nom = value; }

        public Personne(int id, string nom)
        {
            this.id = id;
            this.nom = nom;
        }




        public Personne(String n)
        {
            this.nom = n;
            this.id = Compteur;
            Compteur++;
        }



        public void AfficherDBG()
        {
            Console.WriteLine("Personne : " + id + " " + nom);
        }




       public static Random Alea = new Random();
        public static string GenereNbrAlea()
        {
           
            String[]  tab_Voyelle = new String[] { " a ", " e ", " i ", " o ", " u " };
            String[]  tab_Consonne = new String[] { " b ", " c ", " d ", " f ", " g ", " h " };
            int nbS;
            String resultat = " ";

            nbS = Alea.Next(2, 5);

            for (int s=0; s<nbS; s++)
            {
                resultat += tab_Consonne[Alea.Next(tab_Consonne.Length - 1)];
                resultat += tab_Voyelle[Alea.Next(tab_Voyelle.Length - 1)];
            }
            return resultat;
        }



    }
}
