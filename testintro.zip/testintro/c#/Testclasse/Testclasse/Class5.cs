﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Testclasse
{


    class Facture
    {
       private string numFacture;

        public string NumFacture { get => numFacture; set => numFacture = value; }
    }

}
