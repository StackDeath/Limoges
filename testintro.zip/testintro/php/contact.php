<?php

//  echo "test d'envoi de mail";
// 
//  $to      = 'massyclement942@gmail.com';
//  $subject = 'le sujet';
//  $message = 'Bonjour !';
//  $headers = 'From: no-reply@kroko.ovh' . "\r\n" .
//  'Reply-To: no-reply@kroko.ovh' . "\r\n" .
//  'X-Mailer: PHP/' . phpversion();
//
 // mail($to, $subject, $message, $headers); 

if (isset($_GET["message"]))
{
    $message = "Ce message provient du site donc c'est un franc succès 
    Nom : ". $_GET["nom"] . "
    Email : " . $_GET["email"] . "
    Sujet : " . $_GET["sujet"] . "
    Message : " . $_GET["message"];

    $retour = mail("massyclement942@gmail.com", $_GET["sujet"],
    $message, "From:contact@https://kroko.ovh/~massy/testintro/Intro.html". "\r\n" . "Reply-to" . $_GET ["email"]);
    'X-Mailer: PHP/' . phpversion();

    if ($retour) {
        echo "<p> L'email a bien été envoyé. </p>";
    }
}